# Cascaded power revision — 26 September 2026

## Implemented

The manual schematic now uses:

```text
VM → U201 LMR36510 + L201 → VCC (10.01 V) → STSPIN gate driver + brake driver
                                       └→ U205 TPS82150 → 5V_BAT ┐
USB → existing protection → 5V_USB ──────────────────────────────┤ U203 mux
                                                               └→ 5V_SYS → U204 → 3V3
```

The user-built bridge and PCB are byte-for-byte unchanged. The auxiliary and gate-driver sheets contain the circuit changes; the overview is updated. MCU and current-sensing sheets only received the matching cached STSPIN symbol definition: SW is passive in this externally supplied configuration. Its footprint, pin numbering and other pins are unchanged.

## Why 10 V

12 V is allowed, but the CSD88599Q5DC resistance and loss specifications already use 10 V gate drive. There is no quantified 12 V benefit here to justify raising the setpoint. The internal STSPIN converter's 200 mA limit did **not** prohibit 12 V: it supports 8/10/12/15 V. The new TPS82150 accepts either 10 or 12 V.

Retaining 10 V avoids unnecessary gate-charge energy and gives more margin below the module's 17 V recommended input maximum. At VM close to or below 10 V, the first buck enters dropout; it cannot maintain a 10 V output from a lower input. Gate drive must still obey the driver's undervoltage lockout.

## Changed parts and connections

| Reference | Change / reason |
|---|---|
| U201 | Retain LMR36510FADDAR: 1 A, adjustable, 400 kHz FPWM. |
| R201 / R202 | 100 kΩ / **11.1 kΩ**, 1%; 1.0 × (1 + 100/11.1) = **10.009 V**. |
| L201 | **47 µH, Würth 74437349470**. The higher output voltage needs reconsideration of the inductor, not just the divider. Same 7050 package family and downloaded STEP as before. |
| C205 / C206 | 22 µF each, upgraded from 10 V to **25 V X7R**, 1210. Pair specification: at least 22 µF effective at 10 V. |
| U205 | **TPS82150SILR**, integrated-inductor 1 A buck, 3.0 × 2.8 × 1.5 mm. |
| R216 / R217 | 105 kΩ / 20 kΩ, **0.1%**; 0.8 × (1 + 105/20) = **5.000 V**. Bottom resistor is below TI's recommended 100 kΩ maximum. |
| C214 / C215 | Local module input bypass: 2 × 22 µF, 25 V X7R, 1210. Require at least 10 µF effective total at 10 V. |
| C218 / C219 | Module output: 2 × 22 µF, 16 V X7R, 1210. Require at least 22 µF effective total at 5 V. |
| C216 | 10 nF soft-start capacitor: approximately 5 ms. |
| R218 / 10V_GOOD | 100 kΩ pull-up to VCC on U201's open-drain PG, driving U205 EN. U205 waits for the upstream supply. Its own PG is intentionally unused. |
| L301 / D302 | Removed from the STSPIN converter. |
| U4 pins 61/62/63 | **VM → VM, SW → VM, VCC → external 10 V**, matching ST Figure 7. C311 remains on VM; C312/C313 remain beside the VCC input electrically. |
| U4 REGIN / REG3V3 | Existing external 3.3 V bypass retained, matching ST Figure 12. |

TP1003 now probes VCC/10 V. The former 5V_BAT power flag was removed because U205 now drives this rail explicitly. USB priority, the user's ST-line test point and the downstream LDO are retained.

## Startup, current and noise

- U201 starts from VM, then its PG permits U205 to start. U203 chooses between battery-derived 5 V and USB; its existing reverse-current blocking separates the two sources. USB alone does not energize VCC or the gates.
- The obsolete firmware instruction to change the internal VCC regulator from 8 to 10 V is removed. External resistor values now determine VCC. Firmware must still initialize protections, check driver readiness, charge the bootstrap capacitors and handle VM loss/return before enabling PWM. No firmware was changed in this task.
- At an **illustrative** 320 mA load on 5 V, 85% conversion efficiency and 50 mA allowance for gate/brake/driver load, the 10 V rail supplies about **238 mA**. Even 1 A at 5 V gives about 638 mA upstream under those assumptions. This is sizing headroom, not a measured total board power budget or a thermal guarantee.
- L201 ripple is about 0.405 A peak-to-peak at 42 V input. A stress calculation at 54 V, minimum frequency 340 kHz and −20% inductance gives 0.637 A. At the illustrative full module load above, peak current is approximately 0.96 A, below the inductor's 1.8 A / 10% saturation-drop specification. The board's motor-voltage limit is not changed by this 54 V stress calculation.
- TPS82150 uses pulse-frequency modulation at light load. This is a compact module, **not an EMI-free supply**. Keep its input capacitors immediately at VIN/GND, output capacitors at VOUT/GND, FB divider close to FB and away from the module's magnetic field. Route VCC separately from the auxiliary source to the gate driver and module, with local bypass at both destinations; do not route the gate's pulse-current return through the module/feedback return.
- The module replaces the large second discrete inductor and diode with a small package plus its required passives. Actual area reduction depends on placement; no PCB-area claim has been measured.

## Verification and limits

**Passed:** native KiCad netlist export; every pre-existing pin-to-net association compared with the saved baseline, allowing only the intentional rail changes and removed parts; U205 pins 1–9 and STSPIN supply pins explicitly checked; exact unchanged bridge/PCB hashes; native ERC has **the same 16 existing findings and zero new findings**. No ERC exclusions were added. Existing bridge pin-range/library issues remain outside this change.

The two dividers were also checked with ngspice: 10.009 V produces 1.000 V at U201 FB; 5.000 V produces 0.800 V at U205 FB. Conservative component/reference tolerance estimates are 9.683–10.344 V and approximately 4.888–5.163 V respectively. These exclude switching overshoot and dynamic load effects. Detailed values are in `validation.json`.

The general schematic analyzer guessed incorrect feedback reference voltages and flagged PG/EN as supplies needing decoupling. Those heuristic findings were rejected against the datasheets; the native netlist and explicit manufacturer pin functions are the evidence used here. The SPICE check is a **divider check only**, not a simulation of either regulator's control-loop stability.

**Still to qualify before assembly:** select exact capacitor MPNs and confirm that DC bias, tolerance, temperature and aging leave the effective capacitances specified above. The generic nominal values alone are not sufficient evidence. Power-up/load-step behaviour, VCC spikes, heat and EMI require validation on the placed/routed hardware. No availability or fabricator checks were performed.

## CAD

U205 uses a local copy of KiCad's standard **SIL0008D MicroSiP-8-1EP** footprint, with the TPS82150 pin map checked against TI's drawing: outer pads 1–8 and central ground pad 9. The standard IPC land pattern uses 0.625 × 0.5 mm peripheral pads and a 1.1 × 1.9 mm central pad; TI's example uses smaller 0.5 × 0.4 mm peripheral lands. These are deliberately not claimed to be identical artwork. Pin ordering, pitch and central-pad size match. Solder mask, paste and thermal-via implementation still belong in the PCB review.

**U205's exact STEP model is missing.** The bundled KiCad footprint referred to a nonexistent model, and the upstream path also returned 404. That dangling association was removed. Download CAD for **TPS82150SILR / SIL0008D**, not the similarly named ten-pin SIL0010A. No substitute model was invented.

L201 uses the same verified 7050 land geometry and family STEP as the previous inductor, now associated with the 47 µH ordering code. STSPIN and MOSFET imported CAD are untouched.

## Evidence

- [TI LMR36510 datasheet](https://www.ti.com/lit/ds/symlink/lmr36510.pdf): divider, frequency, current limits and inductor recommendations.
- [TI TPS82150 datasheet](https://www.ti.com/lit/ds/symlink/tps82150.pdf): pins, input/output range, capacitance, soft start, SIL0008D drawing and layout guidance.
- [STSPIN32G4 datasheet](https://www.st.com/resource/en/datasheet/stspin32g4.pdf): Figures 7 and 12, external VCC and 3.3 V bypass.
- [TI CSD88599Q5DC datasheet](https://www.ti.com/lit/ds/symlink/csd88599q5dc.pdf): gate limits and 10 V specifications.
- [Würth 74437349470 datasheet](https://www.we-online.com/components/products/datasheet/74437349470.pdf): 47 µH electrical and package specifications.

Saved starting project: `../../../backups/manual_before_cascaded_power_2026-09-26.zip`.
