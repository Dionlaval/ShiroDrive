# Footprint and 3D CAD download checklist

The complete P1 schematic has been copied into the manual hierarchy, retaining your MOSFET bridge. This is a **review baseline**, not a PCB release. Package descriptions below come from the current schematic assignments; they do not claim that a vendor CAD bundle has been found or validated. Stock and fabricator checks were not performed.

## Where to put downloads

Put the original ZIP bundles in **`incoming/`**, or unpack each part into a separate folder named for its exact part number, for example `incoming/TPS2121RUXR/`. Keeping the original ZIP makes the source and licence information easy to retain without scattering files through the project.

For each exact part, download:

- A **KiCad footprint** (`.kicad_mod`, often inside a `.pretty` folder).
- A **STEP model** (`.step` or `.stp`) when available.
- The bundled **symbol** (`.kicad_sym`) is optional, but useful for checking pad numbers. We will keep the functional schematic symbols and associate the footprint rather than replace the circuit symbol.

Use the exact ordering code in the tables as the search term. A 3D model is useful for mechanical checks; it does not establish whether the footprint pads are correct. Do not substitute a look-alike package just because the body dimensions match.

Ultra Librarian supports KiCad footprint/model import: [KiCad import instructions](https://app.ultralibrarian.com/content/help/kicad-6_0.htm). Manufacturer CAD is also suitable. Standard footprints and models are supplied by the [official KiCad libraries](https://www.kicad.org/libraries/download/).

## Already downloaded — keep these

| References | Part | Existing association | Action |
|---|---|---|---|
| U4, units A–F | STSPIN32G4 | `Manual:QFN_IN32G4_STM` | No new download. Imported footprint and STEP link retained. |
| U1, U2, U3 | CSD88599Q5DC | `Manual:DMM0022A` | No new download. Reconcile symbol pins with this footprint before PCB update. |

**Existing MOSFET mapping issue:** the retained symbol has literal pin numbers `[3-11]` and `[12-20]`, but the imported footprint has separate numbered pads. It also contains additional pads without matching symbol pins, including pads numbered `V`. This needs a package/pin mapping check using the original downloaded library and datasheet. The bridge has deliberately been preserved as requested; downloading the same package again will not fix that mapping by itself.

## 1. Replace the three inherited custom footprints first

| Download | Exact part number / search term | References | Current package / important distinction |
|---|---|---|---|
| ☐ | `CSD19531Q5A` | Q501 | TI Q5A / DQJ0008A; exposed-drain power package |
| ☐ | `74437349220` | L201, L301 | Würth WE-LHMI 7050; exact inductor outline |
| ☐ | `TLV75533PDYDR` | U204 | TI DYD0005A, five-pad SOT-23 variant |

## 2. Other ICs — exact-part footprints and STEP models

| Download | Exact part number / search term | References | Current package / important distinction |
|---|---|---|---|
| ☐ | `LMR36510FADDAR` | U201 | TI DDA, HTSOP-8 + exposed pad |
| ☐ | `TPS2121RUXR` | U203 | TI RUX, VQFN-HR-12, 2 × 2.5 mm |
| ☐ | `AS5047P-ATSM` | U601 | TSSOP-14, 4.4 × 5 mm, 0.65 mm pitch |
| ☐ | `BMI323` | U701 | Bosch LGA-14, 3 × 2.5 mm |
| ☐ | `TMUX1574PW` | U602 | TSSOP-16, 4.4 × 5 mm, 0.65 mm pitch |
| ☐ | `TCAN3413DR` | U801 | SOIC-8, 3.9 × 4.9 mm |
| ☐ | `CP2102N-A02-GQFN20` | U901 | QFN-20 + exposed pad, 3 × 3 mm; not the 24/28-pin versions |
| ☐ | `UCC27517ADBVR` | U501 | SOT-23-5 / DBV |
| ☐ | `TLV3012BIDBVR` | U502 | SOT-23-6 / DBV |
| ☐ | `USBLC6-2SC6` | U202 | SOT-23-6 |
| ☐ | `TPD3E001DRLR` | D601 | TI DRL-5 / SOT-553; not ordinary SOT-23-5 |
| ☐ | `PESD2CANFD24V-T` | D801 | SOT-23, 3 pins |

## 3. Connectors, bulk capacitors and crystal — useful exact mechanical CAD

| Download | Exact part number / search term | References | Current package / important distinction |
|---|---|---|---|
| ☐ | `XT60PW-M` | J101 | AMASS PCB-mount horizontal male; exact PW variant |
| ☐ | `TYPE-C-31-M-12` | J201 | HRO USB-C receptacle; exact mounting tabs/pads |
| ☐ | `BM06B-GHS-TBT` | J601 | JST GH, 6 contacts, vertical, 1.25 mm pitch |
| ☐ | `BM04B-GHS-TBT` | J801, J802 | JST GH, 4 contacts, vertical, 1.25 mm pitch |
| ☐ | `FTSH-105-01-L-DV-K` | J1001 | Samtec 2 × 5 SWD header, 1.27 mm pitch; match locating features |
| ☐ | `EEVFK1J681M` | C101, C102, C103 | Panasonic 680 µF / 63 V; currently 18 × 17.5 mm SMD can |
| ☐ | `0132M4-24.000F07DTNLL` | Y301 | 3.2 × 2.5 mm, four-pad crystal; verify pad orientation |

## 4. Optional downloads — standard packages already assigned

| Download | Exact part number / search term | References | Current package / important distinction |
|---|---|---|---|
| ☐ | `STPS1H100A` | D302 | SMA |
| ☐ | `BAT54H,115` | D502, D503 | SOD-123F; comma is part of this ordering code |
| ☐ | `BZT52C12` | D501 | SOD-123; manufacturer not fixed in schematic |
| ☐ | `B5100C-13-F` | D504 | SMC |
| ☐ | `NCP18XH103F03RB` | TH701, TH702, TH703 | 0603 / 1608 thermistor; standard chip outline |

The installed STEP links for **J101, U203, D601, J201 and U901** currently point to missing files. Their exact-part downloads above will address those gaps. J501 also references a missing optional wire model; it is a solder-wire PCB feature and does not need a connector download.

## 5. Choose these parts before downloading CAD

These are still generic or unassigned in the retained manual bridge / copied source. There is no unique package to download yet.

| References | What is undecided | Reference-design starting point, not an automatic selection |
|---|---|---|
| R1, R3, R5 | Shunt resistance, exact part and footprint | P1 used `BVR-Z-R0005-1.0`, a 0.5 mΩ four-terminal shunt. The sensing scale assumes that resistance. Your `R_Shunt` placeholders are retained. |
| J1 | Motor connector or direct solder-wire pads | P1 used three 6 mm² solder-wire pads, not a purchased connector. Choose the mechanical termination you want. |
| C4, C8, C12 | Bootstrap capacitance, rating and footprint | Currently named `BOOTSTRAP1`, not given a capacitance. P1 used 100 nF / 25 V; retain as a review choice. |
| C1–C3, C5–C7, C9–C11 | Bridge ceramic voltage rating and package | Values are retained; no footprints assigned. Choose parts/packages with suitable voltage and effective capacitance before matching CAD. |
| R2, R4, R6 | Gate resistor package | 4.7 Ω retained; footprint still blank. Standard resistor footprint once size is chosen. |
| SW301, SW1001, SW1002 | Exact pushbutton | Existing assignment is `SW_SPST_TL3305A`; exact ordering suffix/actuator height is not selected. Download after choosing, or remove during your review. |
| D301 | Exact red LED | Standard 0603 footprint already assigned. Exact LED only needed for part selection / appearance. |
| D101 | Optional input TVS | DNP/tuning placeholder. SMC footprint exists; choose exact TVS only if retaining it. |
| R102, C107 | Optional input damping values/parts | DNP/tuning placeholders. No exact part selected. |

## No separate download needed

- Ordinary resistors/capacitors: the assigned KiCad metric footprints cover 0603, 0805, 1206, 1210, 2220 and 2512 as used. Do not download a different model for each resistance or capacitance.
- H1–H4: standard 3.2 mm M3 non-plated clearance-hole footprints. Screws/standoffs are separate mechanical choices.
- Test pads, JP801 solder jumper, and J501 direct solder-wire brake connection: PCB features, not purchased connector bodies.
- The optional standard-package parts in section 4 already have KiCad footprints. Exact vendor downloads are useful if you want them, but are lower priority than sections 1–3.

## What I will do once the files are here

1. Match each bundle by exact MPN and the reference list in `component_footprint_map.csv`.
2. Check footprint pad numbers, pin 1 orientation, exposed pads and body/land dimensions against the symbol and package drawing.
3. Keep validated footprints in `../libs/Manual.pretty/` and STEP files in `../libs/3dmodels/`.
4. Assign `Manual:<footprint>` to the appropriate schematic components, including every unit of multi-unit ICs.
5. Link models with project-relative paths; inspect their scale, rotation, height and alignment.
6. Report unresolved matches rather than guessing. Update the PCB only when we agree that the schematic review and mapping are ready.

Your component-removal review comes next. DNP means “do not populate”; the part may still occupy PCB space until its footprint is removed. No optional circuitry outside your already-simplified bridge has been removed automatically.
