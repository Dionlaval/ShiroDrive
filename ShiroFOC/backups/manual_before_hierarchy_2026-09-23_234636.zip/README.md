# Manual rebuild

Open [ShiroFOC_Manual.kicad_pro](ShiroFOC_Manual.kicad_pro) in KiCad. This is your independent circuit rebuild; existing generation scripts do not target this folder.

## One project library name: Manual

```text
libs/
├── Manual.kicad_sym                 # all project symbols
├── Manual.pretty/                  # all project footprints
│   ├── DMM0022A.kicad_mod
│   └── QFN_IN32G4_STM-L.kicad_mod
└── 3dmodels/                        # model files
    ├── DMM0022A.stp
    └── QFN_IN32G4_STM.step
```

A `.kicad_sym` file is a library containing multiple symbols. A `.pretty` directory is a library containing individual `.kicad_mod` footprint files. These different formats are normal; both libraries use the name **Manual** in KiCad.

| Symbol | Assigned footprint |
|---|---|
| `Manual:CSD88599Q5DC` | `Manual:DMM0022A` |
| `Manual:STSPIN32G4` | `Manual:QFN_IN32G4_STM-L` |

The root `sym-lib-table` and `fp-lib-table` register these project libraries. Standard KiCad libraries remain available through your installation.

## Adding another downloaded part

1. Open the downloaded symbol library in Symbol Editor, temporarily adding it as a project library if needed.
2. Copy the desired symbol into **Manual** using Save As. Do not replace `Manual.kicad_sym` with the downloaded file.
3. Put the footprint's `.kicad_mod` file inside `libs/Manual.pretty/`.
4. Set the symbol's Footprint property to `Manual:footprint_name`.
5. Put any STEP model in `libs/3dmodels/`; link it in Footprint Properties → 3D Models using `${KIPRJMOD}/libs/3dmodels/filename.step`. Check its orientation and position in the preview.
6. Remove the temporary imported library entry after copying. Place the symbol from **Manual**. For symbols already placed from another library, change their library link to the matching Manual symbol as well.

The two model files are present, but the current footprint files contain no model associations. Linking and aligning those models is still a separate step.

## Preservation and scope

The 22 September library cleanup merged the imported STSPIN symbol into Manual and updated its schematic library link and default footprint association. It preserved the edited MOSFET symbol and schematic wiring. The original files are backed up in `../backups/manual_library_cleanup_2026-09-22_231459/`.

Library organisation is not an electrical or footprint-geometry review. The downloaded MOSFET footprint still includes thermal pads numbered `V` without a matching symbol pin; that previously identified issue remains for review.

## References

- [Existing P1 project](../ShiroFOC_KiCad_P1/ShiroFOC_KiCad.kicad_pro)
- [Design notes and workspace index](../README.md)
- [Learning lab](../../learning/README.md)
