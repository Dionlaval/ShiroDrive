# Manual rebuild

Open [ShiroFOC_Manual.kicad_pro](ShiroFOC_Manual.kicad_pro) in KiCad. This is your independent circuit rebuild; existing generation scripts do not target this folder.

## Page hierarchy

The A3 overview has eleven navigable functional sections, arranged like the reference project with larger overview text. Open a sheet box or use KiCad's hierarchy tree.

The bridge retains your corrected capacitor wiring on A4. Page 4 contains the MCU unit on A4; page 5 contains gate-driver and power units on A3; page 7 contains the three current-sensing channels on A3. Seven other sections remain empty: DC link, auxiliary power, brake chopper, SPI sensors, feedback selection, CAN and USB service. Temperature sensing is still to build.

Overview arrows describe the planned architecture; they are graphics, not electrical connections. A complete backup from before this hierarchy change is stored in `../backups/manual_before_hierarchy_2026-09-23_234636.zip`.

## Current sensing — page 7

Three matched resistor networks connect the bridge Kelvin sense pads to U4's internal OPAMP1/2/3. The triangles are now real electrical units U4D/U4E/U4F of the same physical U4 package. Each network uses two 1 kΩ input resistors, 28 kΩ feedback, and two 56 kΩ bias resistors (all 0.1%, 0603).

Ideal DC response: `VOUT = VREF+/2 + 28 × (SENSE_P − SENSE_N)`. At a 3.3 V reference, zero current produces 1.65 V. With **0.5 mΩ shunts**, sensitivity is 14 mV/A and ±60 A produces 0.81–2.49 V. The existing shunt values are still unassigned; this is a design assumption, not a completed part selection.

Use external-feedback op-amp mode and sample within valid low-side PWM windows. Route Kelvin pairs from the shunt sense pads and keep these resistor networks near U4. VREF+/VDDA supply and decoupling, temperature sensing, and firmware configuration remain later steps. DC arithmetic and exported net connectivity were checked; dynamic settling and hardware performance have not been validated.

Backup before this addition: `../backups/manual_before_current_sense_2026-09-23_235641.zip`.

## STSPIN functional units — 24 September

`Manual:STSPIN32G4_Functional` divides **one U4 IC** into:

| Unit | Function | Page |
|---|---|---|
| U4A | MCU GPIO / clock / SWD | 4 |
| U4B | Three-phase gate driver | 5 |
| U4C | Regulators, MCU supplies, grounds and NC pins | 5 |
| U4D | OPAMP1, phase U | 7 |
| U4E | OPAMP2, phase V | 7 |
| U4F | OPAMP3, phase W | 7 |

All 65 package pins occur once. Each unit keeps `Manual:QFN_IN32G4_STM`; KiCad exports a single U4 component. The imported original `Manual:STSPIN32G4` symbol remains in the library for reference. Do not place that original as another U4 alongside the functional units.

The change adds no physical components. It preserves the latest bridge wiring, passive values, PCB, footprint files, STEP files and existing model transforms. Only the nine op-amp pins are connected to the existing sense networks; the latest bare-MCU state is otherwise retained. Power, clock, gate wiring and supporting components will be chosen together in later steps. No components should be added or omitted automatically from the reference design.

Checks: 65-pin coverage against the imported footprint, one U4 in the exported netlist, unchanged existing circuit connections, expected op-amp connections, unchanged footprint/model/bridge file hashes, and visual inspection of all three edited sheets. ERC falls from 97 to 85 findings with no new findings. The unfinished manual rebuild is not yet ERC-clean or ready for fabrication. The earlier VM/GND short is absent.

Backup: `../backups/manual_before_functional_symbol_2026-09-24_162838.zip`.

## One project library name: Manual

```text
libs/
├── Manual.kicad_sym                 # all project symbols
├── Manual.pretty/                  # all project footprints
│   ├── DMM0022A.kicad_mod
│   └── QFN_IN32G4_STM.kicad_mod
└── 3dmodels/                        # model files
    ├── DMM0022A.stp
    └── QFN_IN32G4_STM.step
```

A `.kicad_sym` file is a library containing multiple symbols. A `.pretty` directory is a library containing individual `.kicad_mod` footprint files. These different formats are normal; both libraries use the name **Manual** in KiCad.

| Symbol | Assigned footprint |
|---|---|
| `Manual:CSD88599Q5DC` | `Manual:DMM0022A` |
| `Manual:STSPIN32G4_Functional` (placed U4) | `Manual:QFN_IN32G4_STM` |

The root `sym-lib-table` and `fp-lib-table` register these project libraries. Standard KiCad libraries remain available through your installation.

## Adding another downloaded part

1. Open the downloaded symbol library in Symbol Editor, temporarily adding it as a project library if needed.
2. Copy the desired symbol into **Manual** using Save As. Do not replace `Manual.kicad_sym` with the downloaded file.
3. Put the footprint's `.kicad_mod` file inside `libs/Manual.pretty/`.
4. Set the symbol's Footprint property to `Manual:footprint_name`.
5. Put any STEP model in `libs/3dmodels/`; link it in Footprint Properties → 3D Models using `${KIPRJMOD}/libs/3dmodels/filename.step`. Check its orientation and position in the preview.
6. Remove the temporary imported library entry after copying. Place the symbol from **Manual**. For symbols already placed from another library, change their library link to the matching Manual symbol as well.

The imported STSPIN footprint already links to `${KIPRJMOD}/libs/3dmodels/QFN_IN32G4_STM.step`. The functional-symbol change preserves that footprint and model association exactly; it does not validate the downloaded copper geometry or model alignment.

## Preservation and scope

The 22 September library cleanup merged the imported STSPIN symbol into Manual and updated its schematic library link and default footprint association. It preserved the edited MOSFET symbol and schematic wiring. The original files are backed up in `../backups/manual_library_cleanup_2026-09-22_231459/`.

Library organisation is not an electrical or footprint-geometry review. The downloaded MOSFET footprint still includes thermal pads numbered `V` without a matching symbol pin; that previously identified issue remains for review.

## References

- [Existing P1 project](../ShiroFOC_KiCad_P1/ShiroFOC_KiCad.kicad_pro)
- [Design notes and workspace index](../README.md)
- [Learning lab](../../learning/README.md)
