# Manual rebuild

Open **[ShiroFOC_Manual.kicad_pro](ShiroFOC_Manual.kicad_pro)** in KiCad.

The schematic and PCB are empty, with standard KiCad defaults. Build each circuit section here as you check the reference design. Existing generation scripts do not target this folder.

## Your custom libraries

Both libraries are registered for this project under the name **Manual**:

- **Symbols:** `libs/Manual.kicad_sym`. In Symbol Editor, select `Manual`, then create a new symbol or copy a standard symbol into this library to edit it.
- **Footprints:** `libs/Manual.pretty/`. In Footprint Editor, save your new footprints to `Manual`.
- **3D models:** `libs/3dmodels/`. Store models here and reference them from footprint properties using `${KIPRJMOD}/libs/3dmodels/filename.step`.

Standard KiCad libraries remain available through your normal installation.

### Imported dual MOSFET

- Symbol: `Manual:CSD88599Q5DC`, stored in `libs/Manual.kicad_sym`.
- Assigned footprint: `Manual:DMM0022A`, stored in `libs/Manual.pretty/DMM0022A.kicad_mod`.
- The Ultra Librarian ZIP contains no 3D model. If downloaded separately, put the STEP file in `libs/3dmodels/` and select it in the footprint's 3D Models properties using `${KIPRJMOD}/libs/3dmodels/filename.step`.
- The original ZIP and extracted files are preserved in [the download archive](../backups/library_downloads/2026-09-22_CSD88599Q5DC/).

Imported on 22 September 2026. Only the symbol's footprint association was changed; geometry and pin definitions remain as downloaded. This is not a footprint validation: the footprint includes thermal pads numbered `V` without a matching symbol pin, which needs review before board use.

## References

- [Existing P1 project](../ShiroFOC_KiCad_P1/ShiroFOC_KiCad.kicad_pro)
- [Existing schematic](../ShiroFOC_KiCad_P1/ShiroFOC_KiCad.kicad_sch)
- [Design notes and workspace index](../README.md)
- [Learning lab](../../learning/README.md)
